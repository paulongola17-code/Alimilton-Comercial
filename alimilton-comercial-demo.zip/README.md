# Alimilton Comercial — Demonstração gratuita

Cardápio digital mobile-first, em português, com autenticação de demonstração, seleção de unidade, encomendas, comanda de mesa e painel de administração.

## Testar sem criar contas nem ativar faturação

A demonstração não precisa de Firebase, cartão bancário ou conta de faturação. Abra [http://127.0.0.1:4173/](http://127.0.0.1:4173/) enquanto o servidor local estiver ligado. O ambiente de demonstração já está preparado.

- No primeiro acesso, escolha **Criar conta** e use dados inventados para experimentar; a conta só existe neste navegador.
- Escolha uma unidade e teste **Em casa** ou **No restaurante** (a segunda opção pede o número da mesa).
- Adicione pratos ao pedido e confirme para ver a encomenda/comanda local.
- Para abrir o painel, use **Painel admin** e a senha inicial **admin123**. Pode editar preços, pratos, unidades e banners.
- As alterações de texto ficam no `localStorage`; as fotografias que carregar ficam como ficheiros Blob no `IndexedDB`. Nenhuma imagem é convertida para Base64.

Estes dados ficam apenas neste navegador e neste computador; não são enviados nem sincronizados com outras pessoas. A autenticação e a senha de demonstração servem apenas para experimentar e não protegem um site público. Limpar os dados do navegador apaga as alterações locais.

Se precisar de iniciar novamente o servidor, abra um terminal na pasta principal do projeto (a que contém `outputs`) e execute:

```powershell
python -m http.server 4173 --directory outputs
```

## Projeto completo

Os ficheiros prontos para publicação estão nesta pasta `outputs`: `index.html`, `app.js` e `reference.css`. Para colocar a versão de demonstração no GitHub Pages, envie esses três ficheiros para a raiz de um repositório e ative **Settings → Pages**. Essa publicação ainda será uma demonstração local por navegador: cada visitante terá dados isolados e o painel não será privado.

## Ligar Firebase futuramente

O site mantém a integração preparada, mas a configuração está vazia de propósito para não ligar serviços ou faturação. Para autenticação real e dados sincronizados, use o [guia Firebase](./GUIA-PUBLICACAO.md). O modo de teste continua disponível quando a configuração estiver vazia.
