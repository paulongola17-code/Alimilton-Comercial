# Publicar o Alimilton no GitHub Pages com Firebase

Se quer apenas testar sem pagar nem criar contas, consulte primeiro o modo de demonstração gratuita no [README](./README.md). Este guia é apenas para uma futura ligação Firebase.

Este site é estático: o GitHub Pages publica os ficheiros `index.html`, `app.js` e `reference.css`. O Firebase é o serviço separado que fornece login, Firestore e Storage. As coleções e os dados iniciais são criados pelo código na primeira execução, depois de os serviços e as permissões Firebase estarem configurados.

## 1. Criar a conta e o projeto Firebase

1. Tenha uma conta Google e entre em [Firebase Console](https://console.firebase.google.com/).
2. Clique em **Criar um projeto**, escolha um nome como `Alimilton Comercial` e conclua a criação. O ID do projeto é permanente.
3. No resumo do projeto, clique em **Adicionar app** e escolha a plataforma Web (`</>`). Dê um nome à app e registe-a.
4. Copie o objeto de configuração Web apresentado pelo Firebase. No início de `app.js`, substitua os valores vazios em `firebaseConfig` pelos valores do seu projeto (`apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId` e `appId`). A configuração Web identifica o projeto; não coloque senhas, chaves de conta de serviço nem tokens nesse ficheiro.

## 2. Ativar os serviços Firebase

1. **Authentication:** em **Authentication → Sign-in method**, ative **E-mail/senha**. Se também quiser aceitar telefones, ative **Telefone** e autorize o envio de SMS para Angola (`+244`) nas definições de política regional. O acesso por telefone usa SMS e verificação reCAPTCHA.
2. **Firestore:** em **Firestore Database**, crie a base de dados e escolha a localização com cuidado. Depois de criada, a localização não pode ser alterada. O app inicializa categorias, pratos, filiais, banners e marcadores quando as regras permitem; não é preciso criar as coleções manualmente.
3. **Storage:** em **Storage**, crie o bucket e escolha a localização. O upload de fotografias depende deste serviço. A documentação atual exige o plano **Blaze**, ligado a uma conta de faturação, para usar Cloud Storage for Firebase. É um plano de pagamento conforme o uso; podem existir custos acima das quotas sem custo. Consulte preços e configure alertas antes de ativar a faturação.

## 3. Configurar segurança antes de receber pedidos reais

O painel atual verifica a senha administrativa no código do navegador. Isso não é uma autorização segura do lado do servidor: alguém pode inspecionar o site público e tentar escrever diretamente no Firebase. As regras de Firestore e Storage devem impedir que clientes comuns alterem pratos, filiais, banners e configurações.

Não deixe o Firestore ou o Storage em **modo de teste** nem publique regras como `allow read, write: if true` para um site público. Antes de operar com clientes, é necessário configurar regras de acesso adequadas e uma identidade de administrador verificável pelo Firebase. A senha inicial de demonstração também deve ser substituída. Sem essas alterações, trate a publicação como uma pré-visualização, sem dados reais.

## 4. Colocar os ficheiros no GitHub

1. Crie ou entre na sua conta em [GitHub](https://github.com/).
2. Clique em **New repository** e crie um repositório, por exemplo `alimilton-cardapio`. Para GitHub Free, deixe o repositório público para usar GitHub Pages.
3. Descompacte o ZIP deste pacote no computador.
4. No repositório, use **Add file → Upload files** e envie os ficheiros do pacote diretamente para a raiz. Confirme que `index.html` está na raiz do repositório, ao lado de `app.js` e `reference.css`, e conclua em **Commit changes**.

## 5. Ativar GitHub Pages

1. No repositório, abra **Settings → Pages**.
2. Em **Build and deployment**, escolha **Deploy from a branch**.
3. Selecione a branch `main` e a pasta `/(root)`, depois clique em **Save**.
4. Aguarde o workflow de publicação terminar. O endereço será `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`. Por exemplo, se o usuário for `paulo` e o repositório `alimilton-cardapio`, o endereço será `https://paulo.github.io/alimilton-cardapio/`.

## 6. Autorizar o domínio no Firebase

Depois de saber o endereço GitHub Pages, volte a **Firebase Console → Authentication → Settings → Authorized domains** e adicione apenas o domínio, sem `https://` nem caminho: `SEU-USUARIO.github.io`. Faça isso antes de testar o login publicado. Para autenticação por telefone, configure também a política de SMS para Angola.

## 7. Confirmar a configuração

1. Abra a URL do GitHub Pages em uma janela privada e registe uma conta de cliente.
2. Verifique o painel **Authentication → Users** para confirmar que o utilizador foi criado.
3. Confirme no Firestore se os dados iniciais foram criados. Se estiverem vazios ou o app estiver apenas em modo local, verifique primeiro a configuração em `app.js` e as regras do Firestore.
4. Só teste uploads depois de configurar o Storage e as respetivas regras. Os editores enviam ficheiros ao Storage e guardam no Firestore a URL devolvida; não guardam imagens em Base64.

## Links oficiais

- [Criar projeto e registar app Web no Firebase](https://firebase.google.com/docs/web/setup)
- [Firebase Authentication para Web](https://firebase.google.com/docs/auth/web/start)
- [Autenticação por telefone e domínios autorizados](https://firebase.google.com/docs/auth/web/phone-auth)
- [Cloud Storage para Web e requisito de faturação](https://firebase.google.com/docs/storage/web/start)
- [Planos e faturação Firebase](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans)
- [Publicar GitHub Pages a partir de uma branch](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
